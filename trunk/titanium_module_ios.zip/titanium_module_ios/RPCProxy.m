/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

#import "RPCProxy.h"

#import "TiUtils.h"
#import "Request.h"
#import "Response.h"
#import "MobileService.h"
#import "SBJsonParser.h"
#import "SBJsonWriter.h"
#import "StringUtil.h"

@implementation RPCProxy

+(RPCProxy *) withInit
{
	RPCProxy *instance = [[RPCProxy alloc] init];
	instance = [instance autorelease];
	
	return instance;
}

-(id) invoke:(id)args
{
	//Parse the incoming parameters
	NSArray *parameters = (NSArray *)args;
	NSString *channel = [parameters objectAtIndex:0];
	NSString *payload = [parameters objectAtIndex:1];
	if(channel == nil || payload == nil)
	{
		return nil;
	}
	
	//Set up the RPC Request
	Request *request = [Request withInit:channel];
	
	//Process the JSON string into a dictionary
	SBJsonParser *parser = [[SBJsonParser alloc] init];
	parser = [parser autorelease];
	
	NSError *error;
	NSDictionary *json = [parser objectWithString:payload error:&error];
	
	//Populate the RPC Request with the Name/Value Pairs
	NSArray *keys = [json allKeys];
	for(NSString *attributeName in keys)
	{
		id attributeValue = [json objectForKey:attributeName];
		
		if([attributeValue isKindOfClass:[NSArray class]])
		{
			[request setListAttribute:attributeName :(NSArray *)attributeValue];
		}
		else 
		{
			[request setAttribute:attributeName :(NSString *)attributeValue];
		}
	}
	
	//Make the invocation
	MobileService *service = [MobileService withInit];
	
	Response *response = [service invoke:request];
	
	NSMutableDictionary *object = [NSMutableDictionary dictionary];
	NSArray *names = [response getNames];
	NSSet *arrayNames = [self findArrays:response];
	NSMutableSet *processedArrays = [NSMutableSet setWithCapacity:10];
	for(NSString *name in names)
	{
		if([StringUtil indexOf:name :@"["] != -1 && 
		   [StringUtil indexOf:name :@"["] != -1)
		{
			//This is an array
			int endIndex = [StringUtil indexOf:name :@"["];
			NSString *arrayName = [StringUtil substring:name :0 :endIndex];
			
			if([processedArrays containsObject:arrayName])
			{
				continue;
			}
			
			[processedArrays addObject:arrayName];
			NSArray *value = [self parseListAttribute:response :arrayName];
			if(value != nil)
			{
				[object setObject:value forKey:arrayName];
			}
		}
		else 
		{
			//Simple Name/Value pair
			if(![arrayNames containsObject:name])
			{
				NSString *value = [response getAttribute:name];
				[object setObject:value forKey:name];
			}
		}

	}
	
	//serialize into a json string
	SBJsonWriter *jsonWriter = [[[SBJsonWriter alloc] init] autorelease];
	NSString *jsonResult = [jsonWriter stringWithObject:object];
	
	return jsonResult;
}

-(NSArray *) parseListAttribute:(Response *) response :(NSString *) arrayName
{
	NSArray *list = [response getListAttribute:arrayName];
	
	if(list != nil && [list count] >0)
	{
		int length = [list count];
		NSMutableArray *value = [NSMutableArray array];
		for(int i=0; i<length; i++)
		{
			NSString *local = (NSString *)[list objectAtIndex:i];
			[value addObject:local];
		}
		
		return [NSArray arrayWithArray:list];
	}
	
	return nil;
}

-(NSSet *) findArrays:(Response *)response
{
	NSMutableSet *arrayNames = [NSMutableSet setWithCapacity:10];
	
	NSArray *names = [response getNames];
	for(NSString *name in names)
	{
		if([StringUtil indexOf:name :@"["] != -1 && 
		   [StringUtil indexOf:name :@"["] != -1)
		{
			int endIndex = [StringUtil indexOf:name :@"["];
			NSString *arrayName = [StringUtil substring:name :0 :endIndex];
			[arrayNames addObject:arrayName];
		}
	}
	
	return [NSSet setWithSet:arrayNames];
}
@end
