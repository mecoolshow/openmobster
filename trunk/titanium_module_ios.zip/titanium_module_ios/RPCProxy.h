/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */
#import "TiProxy.h"
#import "Response.h"

@interface RPCProxy : TiProxy 
{
	@private
}

+(RPCProxy *) withInit;

-(id) invoke:(id)parameters;

//Internal Use Only
-(NSArray *) parseListAttribute:(Response *) response :(NSString *) arrayName;
-(NSSet *) findArrays:(Response *)response;
@end
