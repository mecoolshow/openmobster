/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "OrgOpenmobsterCloudModuleAssets.h"

extern NSData * dataWithHexString (NSString * hexString);

@implementation OrgOpenmobsterCloudModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
