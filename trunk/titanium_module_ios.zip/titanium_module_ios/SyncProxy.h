/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */
#import "TiProxy.h"
#import "MobileBean.h"
#import "UpdateBeanProxy.h"
#import "AddBeanProxy.h"

@interface SyncProxy : TiProxy 
{
	@private
}

+(SyncProxy *)withInit;

-(id) readAll:(id)channel;

-(id) readById:(id)input;

-(id) deleteBean:(id) input;

-(id) newBean:(id)input;

@end
