/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

#import "SyncProxy.h"

#import "TiUtils.h"
#import "SBJsonWriter.h"
#import "TitaniumKernel.h"
#import "MobileBean.h"
#import "BeanList.h"

@implementation SyncProxy

+(SyncProxy *)withInit
{
	SyncProxy *instance = [[SyncProxy alloc] init];
	instance = [instance autorelease];
	
	return instance;
}

-(void) dealloc
{
	[super dealloc];
}


-(id) readAll:(id)input
{	
	//Validate the Channel
	NSString *channel = [(NSArray *)input objectAtIndex:0];
	if(channel == nil)
	{
		return nil;
	}
	
	//Read the beans stored in the channel
	NSArray *beans = [MobileBean readAll:channel];
	
	//Get the 'oids' of these beans
	NSMutableArray *oids = [NSMutableArray array];
	if(beans != nil && [beans count]>0)
	{
		for(MobileBean *bean in beans)
		{
			NSString *oid = [bean getId];
			[oids addObject:oid];
		}
	}
	
	//Generate a JSON payload of this array of 'oids'
	SBJsonWriter *jsonWriter = [[[SBJsonWriter alloc] init] autorelease];
	NSString *payload = [jsonWriter stringWithObject:oids];
	
	return payload;	
}

-(id) readById:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *channel = [parameters objectAtIndex:0];
	NSString *oid = [parameters objectAtIndex:1];
	
	//Validate the input
	if(channel == nil || oid == nil)
	{
		return nil;
	}
	
	MobileBean *bean = [MobileBean readById:channel :oid];
	if(bean == nil)
	{
		//Not Found
		return nil;
	}
	
	UpdateBeanProxy *proxy = [UpdateBeanProxy withInit];
	proxy.bean = bean;
	
	return proxy;
	
}

-(id) deleteBean:(id) input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *channel = [parameters objectAtIndex:0];
	NSString *oid = [parameters objectAtIndex:1];
	
	//Validate the input
	if(channel == nil || oid == nil)
	{
		return nil;
	}
	
	//Get the bean to be deleted
	MobileBean *bean = [MobileBean readById:channel :oid];
	if(bean == nil)
	{
		//Not Found
		return nil;
	}
	
	NSString *beanId = [bean getId];
	
	[bean delete];
	
	return beanId;
}

-(id) newBean:(id)input
{	
	NSArray *parameters = (NSArray *)input;
	
	NSString *channel = [parameters objectAtIndex:0];
	
	//Validate the input
	if(channel == nil)
	{
		return nil;
	}
	
	MobileBean *newBean = [MobileBean newInstance:channel];
	if(newBean == nil)
	{
		return nil;
	}
	
	AddBeanProxy *beanProxy = [AddBeanProxy withInit];
	beanProxy.bean = newBean;
	
	return beanProxy;
}
@end
