/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */
#import "TiProxy.h"
#import "MobileBean.h"
#import "TitaniumKernel.h"

@interface AddBeanProxy : TiProxy 
{
	@private
	MobileBean *bean;
}

@property(nonatomic,retain) MobileBean *bean;

+(AddBeanProxy *) withInit;

-(id) oid:(id)input;
-(id) getValue:(id)input;
-(void) setValue:(id)input;
-(id) commit:(id) input;
@end
